import pandas as pd
from helper_functions import *
import first_depth
import second_depth

def crawl_web(website_url, depth=1):
    url = website_url
    all_links = set()
    all_links.add(url)

    # First Depth
    page_links = first_depth.execute(url, window=True)
    all_links.update(page_links)

    df = make_dataframe(all_links)
    df.to_csv(f'data2.csv', index=False)

    print(f"Total Links Collected\t:{len(all_links)}")

    ans = 'yes'
    # Second Depth
    for i in range(depth):
        print(f"Depth\t:{i+1}...")

        if ans == 'yes':
            df = pd.read_csv(f'data2.csv')
            all_links = set(df["Page URL"])

            page_links = second_depth.execute(page_links, all_links, window=True)
            all_links.update(page_links)

            print(f"Total Links Collected\t:{len(all_links)}")

            df = make_dataframe(all_links)
            df.to_csv(f'data.csv2', index=False)

            ans = input("Do you want to continue? (yes/no)\t")
        else:
            break

    return all_links

def make_dataframe(all_links):
    # Make a DataFrame of links
    df = pd.DataFrame(columns=["Page URL"])
    df["Page URL"] = list(all_links)
    return df

if __name__ == "__main__":
    base_url = "https://www.moglix.com/solar/solar-panels/213110000"
    
    # Assuming the site has pages in the format 'base_url?page=1', 'base_url?page=2', etc.
    number_of_pages = int(input("Enter the number of pages to crawl: "))
    depth = int(input("Enter the depth for crawling: "))

    for page in range(1, number_of_pages + 1):
        website_url = f"{base_url}?page={page}"
        can_continue = input(f"Url {website_url} is Correct? (yes/no)\t:")
        if can_continue == 'yes':
            all_links = crawl_web(website_url, depth)
    
    # Apply loop 'ffor j in range(1,1000)' if needed
    for j in range(1, 1000):
        # logic for processing or checking
        pass

    # Check filter_links function
    common_links = [base_url, "https://facebook.com", "other_links"]
    print("==================================================Filter Links===========================================")
    print(filter_links(common_links))

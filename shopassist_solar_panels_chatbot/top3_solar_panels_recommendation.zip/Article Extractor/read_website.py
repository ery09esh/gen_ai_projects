
from tqdm import tqdm
from bs4 import BeautifulSoup
import requests
import re
import pandas as pd

df = pd.read_csv(r'kamlesh_scrapping_program\Web-Crawler-and-Scraper\Article Extractor\a.csv')

all_links = df['Page URL']

articles = []

for link in all_links:

    response = requests.get(link)

    soup = BeautifulSoup(response.text, 'html.parser')

    paras = soup.find('div', class_="prod-detail")

    if paras != None:

        articles.append(paras.text[15:-9])

    else:
        articles.append('None')

new_df = pd.DataFrame()

new_df['Page URL'] = all_links
new_df['Text'] = articles


new_df.to_csv('result6.csv', index=False)